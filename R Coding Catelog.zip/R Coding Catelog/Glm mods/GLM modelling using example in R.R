##-- GLM modelling using example in R

library(GLMsData)


library(help = GLMsData)
