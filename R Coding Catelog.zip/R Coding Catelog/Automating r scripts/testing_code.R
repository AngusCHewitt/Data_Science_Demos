## test autop script
data <- sample(1:100)

save(data, file = "~/rand_data.Rdata")
