update satellites
set `Launch Mass (kg.)` = REPLACE(`Launch Mass (kg.)`, ',', '')
