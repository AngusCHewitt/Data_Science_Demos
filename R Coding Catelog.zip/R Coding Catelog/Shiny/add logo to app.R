titlePanel(title=div(img(height=200, width=200, src="odds-machine-logo1.jpg"))), 
