library("DT")
library("tidyverse")

function(input, output, session) {
  
  output$wdi_table <- renderDT({
    
  })
  
}