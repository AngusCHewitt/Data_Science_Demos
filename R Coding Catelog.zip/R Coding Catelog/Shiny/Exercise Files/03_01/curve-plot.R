curve(x^2, from = -5, to = 5)
