example_data_frame <- data.frame(
  "A" = 1:5,
  "B" = letters[1:5]
)

myVariable <- 1

myVector <- 1:30

myStrings <- letters[1:5]

curve(x^2, from = -5, to = 5)

myStrings

myVariable
