

.libPaths(c("C:/Users/dwol3009/Documents/R/win-library/4.0", "C:/Program Files/R/R-4.0.3/library"))
drake::drake_cache(".drake")$unlock()
drake::r_make()
