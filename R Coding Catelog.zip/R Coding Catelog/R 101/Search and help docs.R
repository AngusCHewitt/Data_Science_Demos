# retrieve help docs for linear modelling funtion attached to stats base package
help("lm")

# search the help docs for any subject matter related to linear modelling
help.search("lm")