# for objects in the global env.
?search() 

# list search path - ordered by rank
?searchpaths() 

# browse all vignettes
browseVignettes()
