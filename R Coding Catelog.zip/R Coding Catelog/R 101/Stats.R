# Ordering and tabulating 
duplicated, unique
merge
order, rank, quantile
sort
table, ftable

# Linear models 
fitted, predict, resid, rstandard
lm, glm
hat, influence.measures
logLik, df, deviance
formula, ~, I
anova, coef, confint, vcov
contrasts

# Miscellaneous tests
apropos("\\.test$")

# Random variables 
(q, p, d, r) * (beta, binom, cauchy, chisq, exp, f, gamma, geom, 
  hyper, lnorm, logis, multinom, nbinom, norm, pois, signrank, t, 
  unif, weibull, wilcox, birthday, tukey)

# Matrix algebra 
crossprod, tcrossprod
eigen, qr, svd
%*%, %o%, outer
rcond
solve