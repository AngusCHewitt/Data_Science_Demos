Multi_Mod <- read.csv("~/ANZDATA SA4 trans and dialysis.csv")

str(Multi_Mod)

plot(Multi_Mod)
help(package="forecast")

help.search("multi variant forecast")