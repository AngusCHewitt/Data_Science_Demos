##-- install pacages with pacman

library(pacman)

p_install_gh("bnosac/cronR", force = TRUE) # isnatll cron addin schedule sheel scripts
p_load('shiny')
p_load('shinyFiles')
p_load('miniUI')
