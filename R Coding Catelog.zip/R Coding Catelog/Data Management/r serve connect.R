
# open rserve connection 
library(Rserve)
Rserve()
