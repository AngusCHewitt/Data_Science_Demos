
View(Team_For_Against_Scoring_Ranks)

table(GD_Rolling_Cates_3_Target_Models)

summary(anytime_mixed_mod_Midfield)


 Rolling_ewma_playing.for_scores =  log(Team_For_Against_Scoring_Ranks[team.name == "St Kilda" & teamStatus == "home"]$Rolling_ewma_playing.for_scores)
 Rolling_ewma_against_scores =  log(Team_For_Against_Scoring_Ranks[team.name == "Essendon" & teamStatus == "away"]$Rolling_ewma_against_scores)
  

##-- filter to the player type in by punter via unqiue ID
pred_Dt %>%
  filter(player.playerId == "CD_I271129") %>%
  mutate(ruck_Rolling_positions = GD_Rolling_Cates_3_Target_Models[player.player.position == "INT" & rolling_Positions == "Ruckman"]$ruck_Rolling_positions) %>%
  mutate(gameday_Positions = GD_Rolling_Cates_3_Target_Models[player.player.position == "INT" & rolling_Positions == "Ruckman"]$gameday_Positions) %>%
  mutate(Rolling_ewma_playing.for_scores =  log(Team_For_Against_Scoring_Ranks[team.name == "Essendon" & teamStatus == "home"]$Rolling_ewma_playing.for_scores)) %>%
  mutate(Rolling_ewma_against_scores =  log(Team_For_Against_Scoring_Ranks[team.name == "GWS Giants" & teamStatus == "away"]$Rolling_ewma_against_scores))  -> pred_Dt_inputs

##-- prob.odds of success
pred_Dt_inputs %>%
  mutate(prob_Anytime_goals = round(predict(anytime_mixed_mod_Ruckman, newdata = pred_Dt_inputs, type = "response") * 100,2)) %>%
  mutate(prob_Two_goals = round(predict(two_mixed_mod_Ruckman, newdata = pred_Dt_inputs, type = "response") * 100,2)) %>%
  mutate(prob_Three_goals = round(predict(three_mixed_mod_Ruckman, newdata = pred_Dt_inputs, type = "response") * 100,2)) %>%
  mutate(odds_Anytime_goals = str_c(round(1/predict(anytime_mixed_mod_Ruckman, newdata = pred_Dt_inputs, type = "response"),2),"/","1")) %>%
  mutate(odds_Two_goals = str_c(round(1/predict(two_mixed_mod_Ruckman, newdata = pred_Dt_inputs, type = "response"),2),"/","1")) %>%
  mutate(odds_Three_goals = str_c(round(1/predict(three_mixed_mod_Ruckman, newdata = pred_Dt_inputs, type = "response"),2),"/","1"))%>%
  select(player.givenName, player.surname, team.name, gameday_Positions, prob_Anytime_goals, prob_Two_goals, prob_Three_goals, odds_Anytime_goals, odds_Two_goals, odds_Three_goals)



##-- test desc vis

glimpse(afl.com_Adv_stats_From_2021_mod_Subset)

afl.com_Adv_stats_From_2021_mod_Subset %>%
  filter(player.givenName == "Saad" ) %>%
  select(Season, round.roundNumber, teamStatus, Rolling_ewma_SAG_stats_HA:Rolling_ewma_Fantasy_goal_Scoring_stats_HA, goals, shotsAtGoal, marksInside50, Goal_scoring_Fantasy_scores) %>%
  gather("var","stats",-round.roundNumber, -Season, -teamStatus) -> selected_player_stats

# Goals + MI50 and SOG in a Bar chart, per player
selected_player_stats %>%
  ggplot(aes(x = round.roundNumber, y = stats, colour = teamStatus)) + geom_point() + geom_line() + 
  facet_wrap(~ Season + var, scales = "free") -> p_selected_player_stats
plotly::ggplotly(p_selected_player_stats)



pred_Dt %>%
  select(player.playerId, player.givenName, player.surname, team.name) %>%
  unique() %>%
  clipr::write_clip()