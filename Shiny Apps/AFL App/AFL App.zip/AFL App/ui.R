library(tidyverse)#tidydata
library(DT)#rshinyadditionalfuns
library(shiny)#rshinyfuns
library(shinydashboard)#Rshinydashboardfuns
library(data.table)#bigdata
library(plotly)#interactiveplot
library(shinyWidgets)#CSSandJavafuns

load("~/Desktop/Odds Machine/AFL App Dev/AFL App/Data/Mod dts/pred_Dt_last_Rec_game.Rdata")#lastrecinfoafltabs



fluidPage(
titlePanel(title=div(img(height=200, width=200, src="odds-machine-logo1.jpg"))), 

##--Tab1 - Player & teamhist, infoto feed predmod
tabsetPanel(
tabPanel("Player & Team Desc info.", 

tabsetPanel(
tabPanel("Player stats & Categories", 

##--inputtemplatreforDTinteractiveplayersearchtable
verticalLayout(
textInput("Player_id", label="Player ID", value="CD_I240399"),

##-- selectiom for GD cum and acutals ggplot H/A
selectInput("GD_stats_GGplot_id", label = "chart_selection", choices = c("fantasy_cum_stats", "fantasy_GS_actuals", "secondary_Cum_stats", "secondary_GD_actuals"), 
            selected = "fantasy_cum_stats"),

##-- player ids and GD stats
DT::dataTableOutput("player_table"), 

##-- output ggplots with GD cuma nd actuals
plotOutput("player_GS_stats_ID"))), 

##-- player ranks within team
tabPanel("Player fantasy scoring & Ranks", 
DT::dataTableOutput("within_Team_ranks")), 

##-- team scoring for and against 
tabPanel("Team For & Against Scoring", 
DT::dataTableOutput("team_Scoring_table")))), 


##---------------------- tab 2 GD Models ------------------##
tabPanel("player Rolling mods", 
tabsetPanel(
tabPanel("Forwards", 

##--sidebarlayoutwithtextinputontheleft(playersearch)andinfotiles(2*2ontheMainPanel, right-handside)
sidebarLayout(
sidebarPanel(
selectInput("pred_Player_id_frwd", label="Player ID", pred_Dt$player.playerId), # select player us unqiue AFL.com id
selectInput("gd_Position_frwd", label="game Day Role", choices=c("BPL", "BPR", "FPL", "FPR", "HBFL", "HBFR", "HFFL", "HFFR", "INT", "SUB", "CHB", "FB", "CHF", "FF", "C", "R", "RR", "RK", "WL", "WR"), selected="FF"), #""playergdposition
selectInput("TOG_frwd", label="Time on Ground", choices=0:6, selected= 5), # GD Position
selectInput("Home_Away_frwd", label="Home or Away Game", choices=c("home", "away"), selected="home"), # Team playing for home or waay
selectInput("playing_For_frwd", label="Team playing For", choices=c("Adelaide Crows", "Brisbane Lions", "Carlton", "Collingwood", "Essendon", "Fremantle", "Geelong Cats", "Gold Coast Suns", "GWS Giants", "Hawthorn", "Melbourne", "North Melbourne", "Port Adelaide", "Richmond", "St Kilda", "Sydney Swans", "West Coast Eagles", "Western Bulldogs"), selected="Carlton"), #"" plying for team
selectInput("playing_Against_frwd", label="Team playing Against", choices=c("Adelaide Crows", "Brisbane Lions", "Carlton", "Collingwood", "Essendon", "Fremantle", "Geelong Cats", "Gold Coast Suns", "GWS Giants", "Hawthorn", "Melbourne", "North Melbourne", "Port Adelaide", "Richmond", "St Kilda", "Sydney Swans", "West Coast Eagles", "Western Bulldogs"), selected="Richmond"), #"" plying for team
selectInput("rank_Within_pos_frwd", label="rank within Team by Position", choices= 1:10, selected = 3) # rank team within & rolling positions
), 

mainPanel(
tableOutput("Frwd_Prob_ODDS") # output prob and odds in table
)
)
),

tabPanel("Frwd_Pt_Ruck", 
 
 ##--sidebarlayoutwithtextinputontheleft(playersearch)andinfotiles(2*2ontheMainPanel, right-handside)
 sidebarLayout(
   sidebarPanel(
     selectInput("pred_Player_id_f_PT_R", label="Player ID", pred_Dt$player.playerId), # select player us unqiue AFL.com id
     selectInput("gd_Position_f_PT_R", label="game Day Role", choices=c("BPL", "BPR", "FPL", "FPR", "HBFL", "HBFR", "HFFL", "HFFR", "INT", "SUB", "CHB", "FB", "CHF", "FF", "C", "R", "RR", "RK", "WL", "WR"), selected="FF"), #""playergdposition
     selectInput("TOG_f_PT_R", label="Time on Ground", choices=0:6, selected= 5), # GD Position
     selectInput("Home_Away_f_PT_R", label="Home or Away Game", choices=c("home", "away"), selected="home"), # Team playing for home or waay
     selectInput("playing_For_f_PT_R", label="Team playing For", choices=c("Adelaide Crows", "Brisbane Lions", "Carlton", "Collingwood", "Essendon", "Fremantle", "Geelong Cats", "Gold Coast Suns", "GWS Giants", "Hawthorn", "Melbourne", "North Melbourne", "Port Adelaide", "Richmond", "St Kilda", "Sydney Swans", "West Coast Eagles", "Western Bulldogs"), selected="Carlton"), #"" plying for team
     selectInput("playing_Against_f_PT_R", label="Team playing Against", choices=c("Adelaide Crows", "Brisbane Lions", "Carlton", "Collingwood", "Essendon", "Fremantle", "Geelong Cats", "Gold Coast Suns", "GWS Giants", "Hawthorn", "Melbourne", "North Melbourne", "Port Adelaide", "Richmond", "St Kilda", "Sydney Swans", "West Coast Eagles", "Western Bulldogs"), selected="Richmond"), #"" plying for team
     selectInput("rank_Within_f_PT_R", label="rank within Team", choices= 1:22, selected = 6) # rank team within & rolling positions
   ), 
   
   mainPanel(
     tableOutput("frwd_PT_ruck_Prob_ODDS") # output prob and odds in table
   )
   )
   ),

tabPanel("Midfield", 
         
         ##--sidebarlayoutwithtextinputontheleft(playersearch)andinfotiles(2*2ontheMainPanel, right-handside)
         sidebarLayout(
           sidebarPanel(
             selectInput("pred_Player_id_Mids", label="Player ID", pred_Dt$player.playerId), # select player us unqiue AFL.com id
             selectInput("gd_Position_Mids", label="game Day Role", choices=c("BPL", "BPR", "FPL", "FPR", "HBFL", "HBFR", "HFFL", "HFFR", "INT", "SUB", "CHB", "FB", "CHF", "FF", "C", "R", "RR", "RK", "WL", "WR"), selected="FF"), #""playergdposition
             selectInput("TOG_Mids", label="Time on Ground", choices=0:6, selected= 5), # GD Position
             selectInput("Home_Away_Mids", label="Home or Away Game", choices=c("home", "away"), selected="home"), # Team playing for home or waay
             selectInput("playing_For_Mids", label="Team playing For", choices=c("Adelaide Crows", "Brisbane Lions", "Carlton", "Collingwood", "Essendon", "Fremantle", "Geelong Cats", "Gold Coast Suns", "GWS Giants", "Hawthorn", "Melbourne", "North Melbourne", "Port Adelaide", "Richmond", "St Kilda", "Sydney Swans", "West Coast Eagles", "Western Bulldogs"), selected="Carlton"), #"" plying for team
             selectInput("playing_Against_Mids", label="Team playing Against", choices=c("Adelaide Crows", "Brisbane Lions", "Carlton", "Collingwood", "Essendon", "Fremantle", "Geelong Cats", "Gold Coast Suns", "GWS Giants", "Hawthorn", "Melbourne", "North Melbourne", "Port Adelaide", "Richmond", "St Kilda", "Sydney Swans", "West Coast Eagles", "Western Bulldogs"), selected="Richmond"), #"" plying for team
             selectInput("rank_Within_Mids", label="rank within Team", choices= 1:22, selected = 6) # rank team within & rolling positions
           ), 
           
           mainPanel(
             tableOutput("Mids_Prob_ODDS") # output prob and odds in table
           )
           )
           ),


tabPanel("Wingman_HBs", 
         
         ##--sidebarlayoutwithtextinputontheleft(playersearch)andinfotiles(2*2ontheMainPanel, right-handside)
         sidebarLayout(
           sidebarPanel(
             selectInput("pred_Player_id_Wing_HB", label="Player ID", pred_Dt$player.playerId), # select player us unqiue AFL.com id
             selectInput("gd_Position_Wing_HB", label="game Day Role", choices=c("BPL", "BPR", "FPL", "FPR", "HBFL", "HBFR", "HFFL", "HFFR", "INT", "SUB", "CHB", "FB", "CHF", "FF", "C", "R", "RR", "RK", "WL", "WR"), selected="FF"), #""playergdposition
             selectInput("Home_Away_Wing_HB", label="Home or Away Game", choices=c("home", "away"), selected="home"), # Team playing for home or waay
             selectInput("playing_For_Wing_HB", label="Team playing For", choices=c("Adelaide Crows", "Brisbane Lions", "Carlton", "Collingwood", "Essendon", "Fremantle", "Geelong Cats", "Gold Coast Suns", "GWS Giants", "Hawthorn", "Melbourne", "North Melbourne", "Port Adelaide", "Richmond", "St Kilda", "Sydney Swans", "West Coast Eagles", "Western Bulldogs"), selected="Carlton"), #"" plying for team
             selectInput("playing_Against_Wing_HB", label="Team playing Against", choices=c("Adelaide Crows", "Brisbane Lions", "Carlton", "Collingwood", "Essendon", "Fremantle", "Geelong Cats", "Gold Coast Suns", "GWS Giants", "Hawthorn", "Melbourne", "North Melbourne", "Port Adelaide", "Richmond", "St Kilda", "Sydney Swans", "West Coast Eagles", "Western Bulldogs"), selected="Richmond"), #"" plying for team
             selectInput("rank_Within_Wing_HB", label="rank within Team", choices= 1:22, selected = 6) # rank team within & rolling positions
           ), 
           
           mainPanel(
             tableOutput("Wing_HB_Prob_ODDS") # output prob and odds in table
           )
           )
           ),

tabPanel("Ruckman", 
         
         ##--sidebarlayoutwithtextinputontheleft(playersearch)andinfotiles(2*2ontheMainPanel, right-handside)
         sidebarLayout(
           sidebarPanel(
             selectInput("pred_Player_id_Ruckman", label="Player ID", pred_Dt$player.playerId), # select player us unqiue AFL.com id
             selectInput("gd_Position_Ruckman", label="game Day Role", choices=c("BPL", "BPR", "FPL", "FPR", "HBFL", "HBFR", "HFFL", "HFFR", "INT", "SUB", "CHB", "FB", "CHF", "FF", "C", "R", "RR", "RK", "WL", "WR"), selected="FF"), #""playergdposition
             selectInput("TOG_Ruckman", label="Time on Ground", choices=0:6, selected= 5), # GD Position
             selectInput("Home_Away_Ruckman", label="Home or Away Game", choices=c("home", "away"), selected="home"), # Team playing for home or waay
             selectInput("playing_For_Ruckman", label="Team playing For", choices=c("Adelaide Crows", "Brisbane Lions", "Carlton", "Collingwood", "Essendon", "Fremantle", "Geelong Cats", "Gold Coast Suns", "GWS Giants", "Hawthorn", "Melbourne", "North Melbourne", "Port Adelaide", "Richmond", "St Kilda", "Sydney Swans", "West Coast Eagles", "Western Bulldogs"), selected="Carlton"), #"" plying for team
             selectInput("playing_Against_Ruckman", label="Team playing Against", choices=c("Adelaide Crows", "Brisbane Lions", "Carlton", "Collingwood", "Essendon", "Fremantle", "Geelong Cats", "Gold Coast Suns", "GWS Giants", "Hawthorn", "Melbourne", "North Melbourne", "Port Adelaide", "Richmond", "St Kilda", "Sydney Swans", "West Coast Eagles", "Western Bulldogs"), selected="Richmond"), #"" plying for team
             selectInput("cnt_Ruckman", label="Cnt Ruckman within Team", choices= 1:2, selected = 1) # rank team within & rolling positions
           ), 
           
           mainPanel(
             tableOutput("Ruckman_Prob_ODDS") # output prob and odds in table
           )
           )
           ),

tabPanel("Defender", 
         
         ##--sidebarlayoutwithtextinputontheleft(playersearch)andinfotiles(2*2ontheMainPanel, right-handside)
         sidebarLayout(
           sidebarPanel(
             selectInput("pred_Player_id_Def", label="Player ID", pred_Dt$player.playerId), # select player us unqiue AFL.com id
             selectInput("gd_Position_Def", label="game Day Role", choices=c("BPL", "BPR", "FPL", "FPR", "HBFL", "HBFR", "HFFL", "HFFR", "INT", "SUB", "CHB", "FB", "CHF", "FF", "C", "R", "RR", "RK", "WL", "WR"), selected="FF"), #""playergdposition
             selectInput("Home_Away_Def", label="Home or Away Game", choices=c("home", "away"), selected="home"), # Team playing for home or waay
             selectInput("playing_For_Def", label="Team playing For", choices=c("Adelaide Crows", "Brisbane Lions", "Carlton", "Collingwood", "Essendon", "Fremantle", "Geelong Cats", "Gold Coast Suns", "GWS Giants", "Hawthorn", "Melbourne", "North Melbourne", "Port Adelaide", "Richmond", "St Kilda", "Sydney Swans", "West Coast Eagles", "Western Bulldogs"), selected="Carlton"), #"" plying for team
             selectInput("playing_Against_Def", label="Team playing Against", choices=c("Adelaide Crows", "Brisbane Lions", "Carlton", "Collingwood", "Essendon", "Fremantle", "Geelong Cats", "Gold Coast Suns", "GWS Giants", "Hawthorn", "Melbourne", "North Melbourne", "Port Adelaide", "Richmond", "St Kilda", "Sydney Swans", "West Coast Eagles", "Western Bulldogs"), selected="Richmond"), #"" plying for team
             selectInput("rank_Within_Def", label="rank within Team", choices= 1:22, selected = 6) # rank team within & rolling positions
             ), 
           
           mainPanel( # output prob and odds in table
             tableOutput("Def_Prob_ODDS")))))),

##---------------------- tab 3 Mosaic & Actual probs ------------------##
tabPanel("Baseline Probs", 
         tabsetPanel(
           tabPanel("Mosaic", 
          sidebarLayout(
            sidebarPanel(        
           selectInput("GD_rolling_Cate", label="Select GD or Rolling Positions", choices = c("gameday_Positions", "rolling_Positions"), selected = "rolling_Positions"), # select player us unqiue AFL.com id
           selectInput("Target_vars", label="Target variable", choices=c("Cnt_ply_1_Goal", "Cnt_ply_2_Goals","Cnt_ply_3_Goals"), selected = "Cnt_ply_1_Goal")), #""playergdposition
           mainPanel(
           plotOutput("Mosaic_Prob_plot")))),
           tabPanel("Actual_Probs",
           DT::dataTableOutput("Actual_Probs_GD_Rolling")),
           tabPanel("sig_Values",
           selectInput("GD_rolling_Mod_select", label="Select Rolling Mod Sig table", choices = c("anytime_mixed_mod_Forward","anytime_mixed_mod_Forward_PT_Ruckman",
                                                                                                  "two_mixed_mod_Forward","two_mixed_mod_Forward_PT_Ruckman",
                                                                                                  "three_mixed_mod_Forward","three_mixed_mod_Forward_PT_Ruckman",
                                                                                                  "anytime_mixed_mod_Midfield","anytime_mixed_mod_Half.Back_Wingman",
                                                                                                  "two_mixed_mod_Midfield","two_mixed_mod_Half.Back_Wingman",
                                                                                                  "anytime_mixed_mod_Ruckman","anytime_mixed_mod_Defender",
                                                                                                  "two_mixed_mod_Ruckman","two_mixed_mod_Defender"), selected = "anytime_mixed_mod_Forward"), # select player us unqiue AFL.com id
           tableOutput("mod_sig_values")
           
           

)
)
)
)
)



