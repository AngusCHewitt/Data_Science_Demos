##-- Server, data loading, manipulation and obj building occurs
library(tidyverse) # tidydata
library(DT) # r shiny additional funs
library(shiny) # Rshiny base package
library(shinydashboard) # Rshiny dashboard funs
library(vcd) #mosaic plots
library(plotly) # interactive plots
library(lme4) #mixed models
library(splines) # ns splines
library(data.table) # big data

##-- App dts
load("~/Desktop/Odds Machine/AFL App Dev/AFL App/Data/player team hist dts/afl.com_Adv_stats_2022_mod_Subset.rds") # player hist since 2021
load("~/Desktop/Odds Machine/AFL App Dev/AFL App/Data/Mod dts/Team_For_Against_Scoring_Ranks.Rdata") # for against scoring 
load("~/Desktop/Odds Machine/AFL App Dev/AFL App/Data/Mod dts/GD_Rolling_Cates_3_Target_Models.Rdata") # Gd and rolling positios comobs
load("~/Desktop/Odds Machine/AFL App Dev/AFL App/Data/Mod dts/pred_Dt_last_Rec_game.Rdata") # last rec info afl tabs
load("~/Desktop/Odds Machine/AFL App Dev/AFL App/Data/Desc dts/odds_Of_success_GD_rolling_Season.Rdata") # actuals prob per GD and roll pos

source("~/Desktop/R functions/data management/load all Object in folder.R") # load all obj in folder fun

Team_For_Against_Scoring_Ranks <- as.data.table(Team_For_Against_Scoring_Ranks) # chnage tibble to data.tabe
GD_Rolling_Cates_3_Target_Models <- as.data.table(GD_Rolling_Cates_3_Target_Models) # chnage tibble to data.tabe


##-- target mod file path
Mod_filepath = "~/Desktop/Odds Machine/AFL App Dev/AFL App/Data/Target mods/"

##-- load all Gd mods
envir = environment()
read_In_objs(Mod_filepath, envir)


##---- Tab 1: player info and stats hist, visuals, feed info to mod, desc statring point

# Define server logic (java logic)
function(input, output, session) 
{

  ##-- Tab 1: All Player Hist  
  ##-- output DT interactive search data table
  output$player_table <- DT::renderDataTable({

    ##-- select player identifiers and rename data frame
    afl.com_Adv_stats_2022_mod_Subset %>%
      select(Match_date:shotsAtGoal, cum_Goal_scoring_Efficiency, marksInside50, fantasy_Rank_ratio, TOG_cate_No) %>%
      arrange(desc(Match_date), team.name) %>%
      mutate(cum_Goal_scoring_Efficiency = round(cum_Goal_scoring_Efficiency,1)) -> afl.com_Adv_stats_From_2021_mod_Subset
    
  }, rownames = FALSE,  filter = "top")


  ##-- Tab 1: Player within team ranks 
  ##-- output DT interactive search data table
  output$within_Team_ranks <- DT::renderDataTable({
    
    ##-- select player identifiers and rename data frame
    afl.com_Adv_stats_2022_mod_Subset %>%
      select(Match_date, team.name, player.playerId, player.givenName, player.surname, rolling_Positions, fantasy_Ranking_within_Team, Frwd_Positions_fantasy_Ranking_within_Team, fantasy_Rank_ratio) %>%
      arrange(desc(Match_date), team.name, fantasy_Ranking_within_Team) -> afl.com_Adv_stats_From_2021_mod_Subset
    
  }, rownames = FALSE,  filter = "top")
  
  
#glimpse(afl.com_Adv_stats_From_2021_mod_Subset)

##-- ggplotof gameday stats, Goals, SOG and Marks iside 50 
output$player_GS_stats_ID <- renderPlot( 
  {  
    
    if (input$GD_stats_GGplot_id == "fantasy_cum_stats") {
    afl.com_Adv_stats_2022_mod_Subset %>%
      filter(player.playerId == input$Player_id) %>%
      select(Season, player.givenName, player.surname, round.roundNumber, teamStatus, Rolling_ewma_SAG_stats_HA:Rolling_ewma_Fantasy_goal_Scoring_stats_HA) %>%
      gather("var","stats",-round.roundNumber, -Season, -teamStatus, -player.givenName, -player.surname) %>%
      mutate(stats = round(stats,1)) -> selected_player_stats
    
    # Goals + MI50 and SOG in a Bar chart, per player
    selected_player_stats %>%
      ggplot(aes(x = round.roundNumber, y = stats, colour = teamStatus)) + geom_point() + geom_line(size = 2) + geom_label(aes(label = stats)) + 
      ggtitle("Goals Scoring Stats from Season 21", paste0(" ",selected_player_stats$player.givenName," ", selected_player_stats$player.surname)) + 
      facet_wrap(~ Season + var, scales = "free") + theme_classic() -> p_selected_player_stats
    p_selected_player_stats
    }
    
    
    else if (input$GD_stats_GGplot_id == "fantasy_GS_actuals") {
      afl.com_Adv_stats_2022_mod_Subset %>%
        filter(player.playerId == input$Player_id) %>%
        select(Season, player.givenName, player.surname, round.roundNumber, teamStatus, goals, shotsAtGoal, marksInside50, Goal_scoring_Fantasy_scores) %>%
        gather("var","stats",-round.roundNumber, -Season, -teamStatus, -player.givenName, -player.surname) %>%
        mutate(stats = round(stats,1)) -> selected_player_stats
      
      # Goals + MI50 and SOG in a Bar chart, per player
      selected_player_stats %>%
        ggplot(aes(x = round.roundNumber, y = stats, colour = teamStatus)) + geom_point() +  geom_line(size = 2)  + geom_label(aes(label = stats)) + 
        ggtitle("Goals Scoring Stats from Season 21", paste0(" ",selected_player_stats$player.givenName," ", selected_player_stats$player.surname)) + 
        facet_wrap(~ Season + var, scales = "free") + theme_classic()-> p_selected_player_stats
      p_selected_player_stats
    }


    else if (input$GD_stats_GGplot_id == "secondary_Cum_stats") {
      afl.com_Adv_stats_2022_mod_Subset %>%
        filter(player.playerId == input$Player_id) %>%
        select(Season, player.givenName, player.surname, round.roundNumber, teamStatus, Rolling_ewma_Def_Stats_HA, Rolling_ewma_extendedStats.ruckContests_HA,
               Rolling_ewma_metresGained_HA) %>%
        gather("var","stats",-round.roundNumber, -Season, -teamStatus, -player.givenName, -player.surname) %>%
        mutate(stats = round(stats,1)) -> selected_player_stats
      
      # Goals + MI50 and SOG in a Bar chart, per player
      selected_player_stats %>%
        ggplot(aes(x = round.roundNumber, y = stats, colour = teamStatus)) + geom_point() + geom_line(size = 2) + geom_label(aes(label = stats)) + 
        ggtitle("Goals Scoring Stats from Season 21", paste0(" ",selected_player_stats$player.givenName," ", selected_player_stats$player.surname)) + 
        facet_wrap(~ Season + var, scales = "free") + theme_classic() -> p_selected_player_stats
      p_selected_player_stats
    }
    
        
    else if (input$GD_stats_GGplot_id == "secondary_GD_actuals") {
      afl.com_Adv_stats_2022_mod_Subset %>%
        filter(player.playerId == input$Player_id) %>%
        select(Season, player.givenName, player.surname, round.roundNumber, teamStatus, Def_Stats, extendedStats.ruckContests, metresGained) %>%
        gather("var","stats",-round.roundNumber, -Season, -teamStatus, -player.givenName, -player.surname) %>%
        mutate(stats = round(stats,1)) -> selected_player_stats
      
      # Goals + MI50 and SOG in a Bar chart, per player
      selected_player_stats %>%
        ggplot(aes(x = round.roundNumber, y = stats, colour = teamStatus)) + geom_point() + geom_line(size = 2) + geom_label(aes(label = stats)) + 
        ggtitle("Goals Scoring Stats from Season 21", paste0(" ",selected_player_stats$player.givenName," ", selected_player_stats$player.surname)) + 
        facet_wrap(~ Season + var, scales = "free") + theme_classic() -> p_selected_player_stats
      p_selected_player_stats
    }
    

    
      })


##-- Hist of the Home and Aways Team  for and against GS ranks and EWMA (Hoem a & Away split)
output$team_Scoring_table <- DT::renderDataTable({
  
  ##-- Team scoring tabls, last rec obs home and away
  Team_For_Against_Scoring_Ranks %>%
    mutate(Rolling_ewma_against_scores = round(Rolling_ewma_against_scores,2),
           Rolling_ewma_playing.for_scores = round(Rolling_ewma_playing.for_scores,2)) -> Team_For_Against_Scoring_Ranks
  
}, rownames = FALSE,  filter = "top")


##---- Tab 2: GD Rolling mods with fixed coef drop downs (inputs) pred/odds (outputs)
          
  ##-- output a sequence of tiles 2 * 2 with prediction / odd at top, player rankings at bottom (++forwards++)
  output$Frwd_Prob_ODDS = renderTable({

  
    ##-- filter to the player type in by punter via unqiue ID
    pred_Dt %>%
      filter(player.playerId == input$pred_Player_id_frwd) %>%
      mutate(GD_roles_Target_1_Goal = GD_Rolling_Cates_3_Target_Models[player.player.position == input$gd_Position_frwd & rolling_Positions == "Forward"]$GD_roles_Target_1_Goal) %>%
      mutate(GD_roles_Target_2_Goal = GD_Rolling_Cates_3_Target_Models[player.player.position == input$gd_Position_frwd & rolling_Positions == "Forward"]$GD_roles_Target_2_Goal) %>%
      mutate(GD_roles_Target_3_Goal = GD_Rolling_Cates_3_Target_Models[player.player.position == input$gd_Position_frwd & rolling_Positions == "Forward"]$GD_roles_Target_3_Goal) %>%
      mutate(gameday_Positions = GD_Rolling_Cates_3_Target_Models[player.player.position == input$gd_Position_frwd & rolling_Positions == "Forward"]$gameday_Positions) %>%
      mutate(TOG_cate_No = as.integer(input$TOG_frwd)) %>%
      mutate(Rolling_ewma_playing.for_scores =  log(Team_For_Against_Scoring_Ranks[team.name == input$playing_For_frwd & teamStatus == input$Home_Away_frwd]$Rolling_ewma_playing.for_scores + 1)) %>%
      mutate(Rolling_ewma_against_scores =  log(Team_For_Against_Scoring_Ranks[team.name == input$playing_Against_frwd & teamStatus == if_else(input$playing_For_frwd == "home","away","home")]$Rolling_ewma_against_scores + 1 )) %>%
      mutate(Frwd_Positions_fantasy_Ranking_within_Team = as.integer(input$rank_Within_pos_frwd)) -> pred_Dt_inputs
    
    ##-- prob.odds of success
      pred_Dt_inputs %>%
       mutate(prob_Anytime_goals = round(predict(anytime_mixed_mod_Forward, newdata = pred_Dt_inputs, type = "response") * 100,2)) %>%
       mutate(prob_Two_goals = round(predict(two_mixed_mod_Forward, newdata = pred_Dt_inputs, type = "response") * 100,2)) %>%
       mutate(prob_Three_goals = round(predict(three_mixed_mod_Forward, newdata = pred_Dt_inputs, type = "response") * 100,2)) %>%
       mutate(odds_Anytime_goals = str_c(round(1/predict(anytime_mixed_mod_Forward, newdata = pred_Dt_inputs, type = "response"),2),"/","1")) %>%
       mutate(odds_Two_goals = str_c(round(1/predict(two_mixed_mod_Forward, newdata = pred_Dt_inputs, type = "response"),2),"/","1")) %>%
       mutate(odds_Three_goals = str_c(round(1/predict(three_mixed_mod_Forward, newdata = pred_Dt_inputs, type = "response"),2),"/","1"))%>%
       select(player.givenName, player.surname, team.name, gameday_Positions, prob_Anytime_goals, prob_Two_goals, prob_Three_goals, odds_Anytime_goals, odds_Two_goals, odds_Three_goals)-> pred_Dt_outputs })



##-- output a sequence of tiles 2 * 2 with prediction / odd at top, player rankings at bottom (**frwd Pt Rucks**)
output$frwd_PT_ruck_Prob_ODDS = renderTable({
  
  
  ##-- filter to the player type in by punter via unqiue ID
  pred_Dt %>%
    filter(player.playerId == input$pred_Player_id_f_PT_R) %>%
    mutate(frwd_PT_ruck_Rolling_positions = GD_Rolling_Cates_3_Target_Models[player.player.position == input$gd_Position_f_PT_R & rolling_Positions == "Forward_PT_Ruckman"]$frwd_PT_ruck_Rolling_positions) %>%
    mutate(gameday_Positions = GD_Rolling_Cates_3_Target_Models[player.player.position == input$gd_Position_f_PT_R & rolling_Positions == "Forward_PT_Ruckman"]$gameday_Positions) %>%
    mutate(TOG_cate_No = as.integer(input$TOG_f_PT_R)) %>%
    mutate(Rolling_ewma_playing.for_scores =  log(Team_For_Against_Scoring_Ranks[team.name == input$playing_For_f_PT_R & teamStatus == input$Home_Away_f_PT_R]$Rolling_ewma_playing.for_scores + 1)) %>%
    mutate(Rolling_ewma_against_scores =  log(Team_For_Against_Scoring_Ranks[team.name == input$playing_Against_f_PT_R & teamStatus == if_else(input$playing_For_f_PT_R == "home","away","home")]$Rolling_ewma_against_scores + 1)) %>%
    mutate(fantasy_Ranking_within_Team = as.integer(input$rank_Within_f_PT_R)) -> pred_Dt_inputs
  
  ##-- prob.odds of success
  pred_Dt_inputs %>%
    mutate(prob_Anytime_goals = round(predict(anytime_mixed_mod_Forward_PT_Ruckman, newdata = pred_Dt_inputs, type = "response") * 100,2)) %>%
    mutate(prob_Two_goals = round(predict(two_mixed_mod_Forward_PT_Ruckman, newdata = pred_Dt_inputs, type = "response") * 100,2)) %>%
    mutate(prob_Three_goals = round(predict(three_mixed_mod_Forward_PT_Ruckman, newdata = pred_Dt_inputs, type = "response") * 100,2)) %>%
    mutate(odds_Anytime_goals = str_c(round(1/predict(anytime_mixed_mod_Forward_PT_Ruckman, newdata = pred_Dt_inputs, type = "response"),2),"/","1")) %>%
    mutate(odds_Two_goals = str_c(round(1/predict(two_mixed_mod_Forward_PT_Ruckman, newdata = pred_Dt_inputs, type = "response"),2),"/","1")) %>%
    mutate(odds_Three_goals = str_c(round(1/predict(three_mixed_mod_Forward_PT_Ruckman, newdata = pred_Dt_inputs, type = "response"),2),"/","1"))%>%
    select(player.givenName, player.surname, team.name, gameday_Positions, prob_Anytime_goals, prob_Two_goals, prob_Three_goals, odds_Anytime_goals, odds_Two_goals, odds_Three_goals)-> pred_Dt_outputs })



##-- output a sequence of tiles 2 * 2 with prediction / odd at top, player rankings at bottom (##-- Mids --##)
output$Mids_Prob_ODDS = renderTable({
  
  
  ##-- filter to the player type in by punter via unqiue ID
  pred_Dt %>%
    filter(player.playerId == input$pred_Player_id_Mids) %>%
    mutate(GD_roles_Target_1_Goal = GD_Rolling_Cates_3_Target_Models[player.player.position == input$gd_Position_Mids & rolling_Positions == "Midfield"]$GD_roles_Target_1_Goal) %>%
    mutate(GD_roles_Target_2_Goal = GD_Rolling_Cates_3_Target_Models[player.player.position == input$gd_Position_Mids & rolling_Positions == "Midfield"]$GD_roles_Target_2_Goal) %>%
    mutate(GD_roles_Target_3_Goal = GD_Rolling_Cates_3_Target_Models[player.player.position == input$gd_Position_Mids & rolling_Positions == "Midfield"]$GD_roles_Target_3_Goal) %>%
    mutate(gameday_Positions = GD_Rolling_Cates_3_Target_Models[player.player.position == input$gd_Position_Mids & rolling_Positions == "Midfield"]$gameday_Positions) %>%
    mutate(TOG_cate_No = as.integer(input$TOG_Mids)) %>%
    mutate(Rolling_ewma_playing.for_scores =  log(Team_For_Against_Scoring_Ranks[team.name == input$playing_For_Mids & teamStatus == input$Home_Away_Mids]$Rolling_ewma_playing.for_scores + 1)) %>%
    mutate(Rolling_ewma_against_scores =  log(Team_For_Against_Scoring_Ranks[team.name == input$playing_Against_Mids & teamStatus == if_else(input$playing_For_Mids == "home","away","home")]$Rolling_ewma_against_scores + 1 )) %>%
    mutate(fantasy_Ranking_within_Team = as.integer(input$rank_Within_Mids)) -> pred_Dt_inputs
  
  ##-- prob.odds of success
  pred_Dt_inputs %>%
    mutate(prob_Anytime_goals = round(predict(anytime_mixed_mod_Midfield, newdata = pred_Dt_inputs, type = "response") * 100,2)) %>%
    mutate(prob_Two_goals = round(predict(two_mixed_mod_Midfield, newdata = pred_Dt_inputs, type = "response") * 100,2)) %>%
    mutate(prob_Three_goals = round(predict(three_mixed_mod_Midfield, newdata = pred_Dt_inputs, type = "response") * 100,2)) %>%
    mutate(odds_Anytime_goals = str_c(round(1/predict(anytime_mixed_mod_Midfield, newdata = pred_Dt_inputs, type = "response"),2),"/","1")) %>%
    mutate(odds_Two_goals = str_c(round(1/predict(two_mixed_mod_Midfield, newdata = pred_Dt_inputs, type = "response"),2),"/","1")) %>%
    mutate(odds_Three_goals = str_c(round(1/predict(three_mixed_mod_Midfield, newdata = pred_Dt_inputs, type = "response"),2),"/","1"))%>%
    
    select(player.givenName, player.surname, team.name, gameday_Positions, prob_Anytime_goals, prob_Two_goals, prob_Three_goals, odds_Anytime_goals, odds_Two_goals, odds_Three_goals)-> pred_Dt_outputs })


##-- output a sequence of tiles 2 * 2 with prediction / odd at top, player rankings at bottom (^^ Wingman & HBs ^^)
output$Wing_HB_Prob_ODDS = renderTable({
  

  ##-- filter to the player type in by punter via unqiue ID
  pred_Dt %>%
    filter(player.playerId == input$pred_Player_id_Wing_HB) %>%
    mutate(GD_roles_Target_1_Goal = GD_Rolling_Cates_3_Target_Models[player.player.position == input$gd_Position_Wing_HB & rolling_Positions == "Half.Back_Wingman"]$GD_roles_Target_1_Goal) %>%
    mutate(GD_roles_Target_2_Goal = GD_Rolling_Cates_3_Target_Models[player.player.position == input$gd_Position_Wing_HB & rolling_Positions == "Half.Back_Wingman"]$GD_roles_Target_2_Goal) %>%
    mutate(GD_roles_Target_3_Goal = GD_Rolling_Cates_3_Target_Models[player.player.position == input$gd_Position_Wing_HB & rolling_Positions == "Half.Back_Wingman"]$GD_roles_Target_3_Goal) %>%
    mutate(gameday_Positions = GD_Rolling_Cates_3_Target_Models[player.player.position == input$gd_Position_Wing_HB & rolling_Positions == "Half.Back_Wingman"]$gameday_Positions) %>%
    mutate(Rolling_ewma_playing.for_scores =  log(Team_For_Against_Scoring_Ranks[team.name == input$playing_For_Wing_HB & teamStatus == input$Home_Away_Wing_HB]$Rolling_ewma_playing.for_scores + 1)) %>%
    mutate(Rolling_ewma_against_scores =  log(Team_For_Against_Scoring_Ranks[team.name == input$playing_Against_Wing_HB & teamStatus == if_else(input$playing_For_Wing_HB == "home","away","home")]$Rolling_ewma_against_scores + 1)) %>%
    mutate(fantasy_Ranking_within_Team = as.integer(input$rank_Within_Wing_HB)) -> pred_Dt_inputs
  
  ##-- prob.odds of success
  pred_Dt_inputs %>%
    mutate(prob_Anytime_goals = round(predict(anytime_mixed_mod_Half.Back_Wingman, newdata = pred_Dt_inputs, type = "response") * 100,2)) %>%
    mutate(prob_Two_goals = round(predict(two_mixed_mod_Half.Back_Wingman, newdata = pred_Dt_inputs, type = "response") * 100,2)) %>%
    mutate(prob_Three_goals = round(predict(three_mixed_mod_Half.Back_Wingman, newdata = pred_Dt_inputs, type = "response") * 100,2)) %>%
    mutate(odds_Anytime_goals = str_c(round(1/predict(anytime_mixed_mod_Half.Back_Wingman, newdata = pred_Dt_inputs, type = "response"),2),"/","1")) %>%
    mutate(odds_Two_goals = str_c(round(1/predict(two_mixed_mod_Half.Back_Wingman, newdata = pred_Dt_inputs, type = "response"),2),"/","1")) %>%
    mutate(odds_Three_goals = str_c(round(1/predict(three_mixed_mod_Half.Back_Wingman, newdata = pred_Dt_inputs, type = "response"),2),"/","1"))%>%
    
    select(player.givenName, player.surname, team.name, gameday_Positions, prob_Anytime_goals, prob_Two_goals, prob_Three_goals, odds_Anytime_goals, odds_Two_goals, odds_Three_goals)-> pred_Dt_outputs })




##-- output a sequence of tiles 2 * 2 with prediction / odd at top, player rankings at bottom (**-- Ruckman --**)
output$Ruckman_Prob_ODDS = renderTable({
  
  
  ##-- filter to the player type in by punter via unqiue ID
  pred_Dt %>%
    filter(player.playerId == input$pred_Player_id_Ruckman) %>%
    mutate(ruck_Rolling_positions = GD_Rolling_Cates_3_Target_Models[player.player.position == input$gd_Position_Ruckman & rolling_Positions == "Ruckman"]$ruck_Rolling_positions) %>%
    mutate(gameday_Positions = GD_Rolling_Cates_3_Target_Models[player.player.position == input$gd_Position_Ruckman & rolling_Positions == "Ruckman"]$gameday_Positions) %>%
    mutate(TOG_cate_No = as.integer(input$TOG_Ruckman)) %>%
    mutate(Rolling_ewma_playing.for_scores =  log(Team_For_Against_Scoring_Ranks[team.name == input$playing_For_Ruckman & teamStatus == input$Home_Away_Ruckman]$Rolling_ewma_playing.for_scores + 1)) %>%
    mutate(Rolling_ewma_against_scores =  log(Team_For_Against_Scoring_Ranks[team.name == input$playing_Against_Ruckman & teamStatus == if_else(input$playing_For_Ruckman == "home","away","home")]$Rolling_ewma_against_scores + 1 )) %>%
    mutate(ruckman_Cnt = as.integer(input$cnt_Ruckman)) -> pred_Dt_inputs
  
  ##-- prob.odds of success
  pred_Dt_inputs %>%
    mutate(prob_Anytime_goals = round(predict(anytime_mixed_mod_Ruckman, newdata = pred_Dt_inputs, type = "response") * 100,2)) %>%
    mutate(prob_Two_goals = round(predict(two_mixed_mod_Ruckman, newdata = pred_Dt_inputs, type = "response") * 100,2)) %>%
    mutate(prob_Three_goals = round(predict(three_mixed_mod_Ruckman, newdata = pred_Dt_inputs, type = "response") * 100,2)) %>%
    mutate(odds_Anytime_goals = str_c(round(1/predict(anytime_mixed_mod_Ruckman, newdata = pred_Dt_inputs, type = "response"),2),"/","1")) %>%
    mutate(odds_Two_goals = str_c(round(1/predict(two_mixed_mod_Ruckman, newdata = pred_Dt_inputs, type = "response"),2),"/","1")) %>%
    mutate(odds_Three_goals = str_c(round(1/predict(three_mixed_mod_Ruckman, newdata = pred_Dt_inputs, type = "response"),2),"/","1"))%>%
    
    select(player.givenName, player.surname, team.name, gameday_Positions, prob_Anytime_goals, prob_Two_goals, prob_Three_goals, odds_Anytime_goals, odds_Two_goals, odds_Three_goals)-> pred_Dt_outputs })


##-- output a sequence of tiles 2 * 2 with prediction / odd at top, player rankings at bottom (<> Defender <>)
output$Def_Prob_ODDS = renderTable({
  
  
  ##-- filter to the player type in by punter via unqiue ID
  pred_Dt %>%
    filter(player.playerId == input$pred_Player_id_Def) %>%
    mutate(GD_roles_Target_1_Goal = GD_Rolling_Cates_3_Target_Models[player.player.position == input$gd_Position_Def & rolling_Positions == "Defender"]$GD_roles_Target_1_Goal) %>%
    mutate(GD_roles_Target_2_Goal = GD_Rolling_Cates_3_Target_Models[player.player.position == input$gd_Position_Def & rolling_Positions == "Defender"]$GD_roles_Target_2_Goal) %>%
    mutate(gameday_Positions = GD_Rolling_Cates_3_Target_Models[player.player.position == input$gd_Position_Def & rolling_Positions == "Defender"]$gameday_Positions) %>%
    mutate(Rolling_ewma_playing.for_scores =  log(Team_For_Against_Scoring_Ranks[team.name == input$playing_For_Def & teamStatus == input$Home_Away_Def]$Rolling_ewma_playing.for_scores + 1)) %>%
    mutate(Rolling_ewma_against_scores =  log(Team_For_Against_Scoring_Ranks[team.name == input$playing_Against_Def & teamStatus == if_else(input$playing_For_Def == "home","away","home")]$Rolling_ewma_against_scores + 1 )) %>%
    mutate(fantasy_Ranking_within_Team = as.integer(input$rank_Within_Def)) -> pred_Dt_inputs
  
  ##-- prob.odds of success
  pred_Dt_inputs %>%
    mutate(prob_Anytime_goals = round(predict(anytime_mixed_mod_Defender, newdata = pred_Dt_inputs, type = "response") * 100,2)) %>%
    mutate(prob_Two_goals = round(predict(two_mixed_mod_Defender, newdata = pred_Dt_inputs, type = "response") * 100,2)) %>%
    mutate(odds_Anytime_goals = str_c(round(1/predict(anytime_mixed_mod_Defender, newdata = pred_Dt_inputs, type = "response"),2),"/","1")) %>%
    mutate(odds_Two_goals = str_c(round(1/predict(two_mixed_mod_Defender, newdata = pred_Dt_inputs, type = "response"),2),"/","1")) %>%

    select(player.givenName, player.surname, team.name, gameday_Positions, prob_Anytime_goals, prob_Two_goals, odds_Anytime_goals, odds_Two_goals)-> pred_Dt_outputs })


##-- output a sequence of tiles 2 * 2 with prediction / odd at top, player rankings at bottom (<> Defender <>)
output$Mosaic_Prob_plot = renderPlot({
  
  if (input$GD_rolling_Cate == "rolling_Positions" & input$Target_vars == "Cnt_ply_1_Goal")
    
  {##-- lagged assoc
    odds_Of_success_GD_rolling_Season %>%
      group_by(rolling_Positions, Season) %>%
      summarise(Count_players = sum(Count_players),
                Cnt_Target = sum(Cnt_ply_1_Goal),
                prop_Target_per_ply =  (Cnt_Target / Count_players)*100,
                ODDS_Target_per_ply =   Count_players / Cnt_Target) %>%
      mutate(prop_Target_per_ply = if_else(is.infinite(prop_Target_per_ply),0, prop_Target_per_ply)) -> cont_tb
    
    
    ##-- reposnse var ODD ratio ~ lower better, red indicates hotspot, blus opposite
    Table <- xtabs(prop_Target_per_ply ~ rolling_Positions + Season, data =  cont_tb)
    mosaic(Table, shade = TRUE,rot_labels=c(45,0,0,-10),  labeling = labeling_values,  gp = shading_Friendly2(Table,c = 500, lty = 1:2))}
  
  else if (input$GD_rolling_Cate == "rolling_Positions" & input$Target_vars == "Cnt_ply_2_Goals")
    
  {##-- lagged assoc
    odds_Of_success_GD_rolling_Season %>%
      group_by(rolling_Positions, Season) %>%
      summarise(Count_players = sum(Count_players),
                Cnt_Target = sum(Cnt_ply_2_Goals),
                 prop_Target_per_ply =  (Cnt_Target / Count_players)*100,
                ODDS_Target_per_ply =   Count_players / Cnt_Target) %>%
      mutate(prop_Target_per_ply = if_else(is.infinite(prop_Target_per_ply),0, prop_Target_per_ply)) -> cont_tb
    
    
    ##-- reposnse var ODD ratio ~ lower better, red indicates hotspot, blus opposite
    Table <- xtabs(prop_Target_per_ply ~ rolling_Positions + Season, data =  cont_tb)
    mosaic(Table, shade = TRUE,rot_labels=c(45,0,0,-10),  labeling = labeling_values,  gp = shading_Friendly2(Table,c = 500, lty = 1:2))}
  
  else if (input$GD_rolling_Cate == "rolling_Positions" & input$Target_vars == "Cnt_ply_3_Goals")
    
  {##-- lagged assoc
    odds_Of_success_GD_rolling_Season %>%
      group_by(rolling_Positions, Season) %>%
      summarise(Count_players = sum(Count_players),
                Cnt_Target = sum(Cnt_ply_3_Goals),
                 prop_Target_per_ply =  (Cnt_Target / Count_players)*100,
                ODDS_Target_per_ply =   Count_players / Cnt_Target) %>%
      mutate(prop_Target_per_ply = if_else(is.infinite(prop_Target_per_ply),0, prop_Target_per_ply)) -> cont_tb
    
    
    ##-- reposnse var ODD ratio ~ lower better, red indicates hotspot, blus opposite
    Table <- xtabs(prop_Target_per_ply ~ rolling_Positions + Season, data =  cont_tb)
    mosaic(Table, shade = TRUE,rot_labels=c(45,0,0,-10),  labeling = labeling_values,  gp = shading_Friendly2(Table,c = 500, lty = 1:2))}
  
  
  else if (input$GD_rolling_Cate == "gameday_Positions" & input$Target_vars == "Cnt_ply_1_Goal")
    
  {##-- lagged assoc
    odds_Of_success_GD_rolling_Season %>%
      group_by(gameday_Positions, Season) %>%
      summarise(Count_players = sum(Count_players),
                Cnt_Target = sum(Cnt_ply_1_Goal),
                 prop_Target_per_ply =  (Cnt_Target / Count_players)*100,
                ODDS_Target_per_ply =   Count_players / Cnt_Target) %>%
      mutate(prop_Target_per_ply = if_else(is.infinite(prop_Target_per_ply),0, prop_Target_per_ply)) -> cont_tb
    
    
    ##-- reposnse var ODD ratio ~ lower better, red indicates hotspot, blus opposite
    Table <- xtabs(prop_Target_per_ply ~ gameday_Positions + Season, data =  cont_tb)
    mosaic(Table, shade = TRUE,rot_labels=c(45,0,0,-10),  labeling = labeling_values,  gp = shading_Friendly2(Table,c = 500, lty = 1:2))}
  
  
  else if (input$GD_rolling_Cate == "gameday_Positions" & input$Target_vars == "Cnt_ply_2_Goals")
    
  {##-- lagged assoc
    odds_Of_success_GD_rolling_Season %>%
      group_by(gameday_Positions, Season) %>%
      summarise(Count_players = sum(Count_players),
                Cnt_Target = sum(Cnt_ply_2_Goals),
                 prop_Target_per_ply =  (Cnt_Target / Count_players)*100,
                ODDS_Target_per_ply =   Count_players / Cnt_Target) %>%
      mutate(prop_Target_per_ply = if_else(is.infinite(prop_Target_per_ply),0, prop_Target_per_ply)) -> cont_tb
    
    
    ##-- reposnse var ODD ratio ~ lower better, red indicates hotspot, blus opposite
    Table <- xtabs(prop_Target_per_ply ~ gameday_Positions + Season, data =  cont_tb)
    mosaic(Table, shade = TRUE,rot_labels=c(45,0,0,-10),  labeling = labeling_values,  gp = shading_Friendly2(Table,c = 500, lty = 1:2))}
  
  else if (input$GD_rolling_Cate == "gameday_Positions" & input$Target_vars == "Cnt_ply_3_Goals")
    
  {##-- lagged assoc
    odds_Of_success_GD_rolling_Season %>%
      group_by(gameday_Positions, Season) %>%
      summarise(Count_players = sum(Count_players),
                Cnt_Target = sum(Cnt_ply_3_Goals),
                 prop_Target_per_ply =  (Cnt_Target / Count_players)*100,
                ODDS_Target_per_ply =   Count_players / Cnt_Target) %>%
      mutate(prop_Target_per_ply = if_else(is.infinite(prop_Target_per_ply),0, prop_Target_per_ply)) -> cont_tb
    
    
    ##-- reposnse var ODD ratio ~ lower better, red indicates hotspot, blus opposite
    Table <- xtabs(prop_Target_per_ply ~ gameday_Positions + Season, data =  cont_tb)
    mosaic(Table, shade = TRUE,rot_labels=c(45,0,0,-10),  labeling = labeling_values,  gp = shading_Friendly2(Table,c = 500, lty = 1:2))}
  
  
  
 },  width = 1000, height = 800)


##-- Actuals Odds and Prob since 2017 stratifiedby GD and Rolling psoitions
output$Actual_Probs_GD_Rolling <- DT::renderDataTable({
  
  ##-- Gd and Rolling odds and probs
  odds_Of_success_GD_rolling_Season %>%
    mutate(prob_Success_1_goals = round(prob_Success_1_goals,4),
           prob_Success_2_goals = round(prob_Success_2_goals,4),
           prob_Success_3_goals = round(prob_Success_3_goals,4),
           Odds_Success_1_goals = round(Odds_Success_1_goals,2),
           Odds_Success_2_goals = round(Odds_Success_2_goals,2),
           Odds_Success_3_goals = round(Odds_Success_3_goals,2)) -> odds_Of_success_GD_rolling_Season
  
  
}, rownames = FALSE,  filter = "top")



##-- Actuals Odds and Prob since 2017 stratifiedby GD and Rolling psoitions
output$mod_sig_values <-renderTable({
  
  if (input$GD_rolling_Mod_select == "anytime_mixed_mod_Forward")
    
  {
  
  tidy_data <- broom.mixed::tidy(anytime_mixed_mod_Forward)
  
  ##-- table of fixed cofe orer by level of sig most to least
  tidy_data %>%
    arrange(desc(abs(statistic))) %>%
    filter(effect == "fixed") } 
  
  
  else if (input$GD_rolling_Mod_select == "two_mixed_mod_Forward")
    
  {tidy_data <- broom.mixed::tidy(two_mixed_mod_Forward)
    
    ##-- table of fixed cofe orer by level of sig most to least
    tidy_data %>%
      arrange(desc(abs(statistic))) %>%
      filter(effect == "fixed") } 
  
  
  else if (input$GD_rolling_Mod_select == "three_mixed_mod_Forward")
    
  {tidy_data <- broom.mixed::tidy(three_mixed_mod_Forward)
  
  ##-- table of fixed cofe orer by level of sig most to least
  tidy_data %>%
    arrange(desc(abs(statistic))) %>%
    filter(effect == "fixed") } 
  
  
  

else if (input$GD_rolling_Mod_select == "anytime_mixed_mod_Forward_PT_Ruckman")
  
{tidy_data <- broom.mixed::tidy(anytime_mixed_mod_Forward_PT_Ruckman)
  
  ##-- table of fixed cofe orer by level of sig most to least
  tidy_data %>%
    arrange(desc(abs(statistic))) %>%
    filter(effect == "fixed") } 


  else if (input$GD_rolling_Mod_select == "two_mixed_mod_Forward_PT_Ruckman")
    
  {tidy_data <- broom.mixed::tidy(two_mixed_mod_Forward_PT_Ruckman)
    
    ##-- table of fixed cofe orer by level of sig most to least
    tidy_data %>%
      arrange(desc(abs(statistic))) %>%
      filter(effect == "fixed") } 
  
  
  else if (input$GD_rolling_Mod_select == "three_mixed_mod_Forward_PT_Ruckman")
    
  {tidy_data <- broom.mixed::tidy(three_mixed_mod_Forward_PT_Ruckman)
  
  ##-- table of fixed cofe orer by level of sig most to least
  tidy_data %>%
    arrange(desc(abs(statistic))) %>%
    filter(effect == "fixed") } 
  
  
  else if (input$GD_rolling_Mod_select == "anytime_mixed_mod_Midfield")
    
  {tidy_data <- broom.mixed::tidy(anytime_mixed_mod_Midfield)
  
  ##-- table of fixed cofe orer by level of sig most to least
  tidy_data %>%
    arrange(desc(abs(statistic))) %>%
    filter(effect == "fixed") } 
  
  
  
  else if (input$GD_rolling_Mod_select == "two_mixed_mod_Midfield")
    
  {tidy_data <- broom.mixed::tidy(two_mixed_mod_Midfield)
  
  ##-- table of fixed cofe orer by level of sig most to least
  tidy_data %>%
    arrange(desc(abs(statistic))) %>%
    filter(effect == "fixed") } 
  
  
  else if (input$GD_rolling_Mod_select == "anytime_mixed_mod_Half.Back_Wingman")
    
  {tidy_data <- broom.mixed::tidy(anytime_mixed_mod_Half.Back_Wingman)
  
  ##-- table of fixed cofe orer by level of sig most to least
  tidy_data %>%
    arrange(desc(abs(statistic))) %>%
    filter(effect == "fixed") } 
  
  
  
  else if (input$GD_rolling_Mod_select == "two_mixed_mod_Half.Back_Wingman")
    
  {tidy_data <- broom.mixed::tidy(two_mixed_mod_Half.Back_Wingman)
  
  ##-- table of fixed cofe orer by level of sig most to least
  tidy_data %>%
    arrange(desc(abs(statistic))) %>%
    filter(effect == "fixed") } 
  
  
  else if (input$GD_rolling_Mod_select == "anytime_mixed_mod_Ruckman")
    
  {tidy_data <- broom.mixed::tidy(anytime_mixed_mod_Ruckman)
  
  ##-- table of fixed cofe orer by level of sig most to least
  tidy_data %>%
    arrange(desc(abs(statistic))) %>%
    filter(effect == "fixed") } 
  
  
  
  else if (input$GD_rolling_Mod_select == "two_mixed_mod_Ruckman")
    
  {tidy_data <- broom.mixed::tidy(two_mixed_mod_Ruckman)
  
  ##-- table of fixed cofe orer by level of sig most to least
  tidy_data %>%
    arrange(desc(abs(statistic))) %>%
    filter(effect == "fixed") } 
  
  
  else if (input$GD_rolling_Mod_select == "anytime_mixed_mod_Defender")
    
  {tidy_data <- broom.mixed::tidy(anytime_mixed_mod_Defender)
  
  ##-- table of fixed cofe orer by level of sig most to least
  tidy_data %>%
    arrange(desc(abs(statistic))) %>%
    filter(effect == "fixed") } 
  
  
  
  else if (input$GD_rolling_Mod_select == "two_mixed_mod_Defender")
    
  {tidy_data <- broom.mixed::tidy(two_mixed_mod_Defender)
  
  ##-- table of fixed cofe orer by level of sig most to least
  tidy_data %>%
    arrange(desc(abs(statistic))) %>%
    filter(effect == "fixed") } 
  
  
  


})



}  




#log(Team_For_Against_Scoring_Ranks[team.name == "Melbourne" & teamStatus == "home"]$Rolling_ewma_playing.for_scores + 1)
